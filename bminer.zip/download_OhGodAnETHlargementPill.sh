#!/bin/sh
wget https://github.com/OhGodACompany/OhGodAnETHlargementPill/raw/master/OhGodAnETHlargementPill-r2 .
chmod 755 OhGodAnETHlargementPill-r2